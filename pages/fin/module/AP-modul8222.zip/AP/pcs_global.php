<html>
<head>
    <title>Export Data Ke Excel </title>
</head>
<body>
    <style type="text/css">
    body{
        font-family: sans-serif;
    }
    table{
        margin: 20px auto;
        border-collapse: collapse;
    }
    table th,
    table td{
        border: 1px solid #3c3c3c;
        padding: 3px 8px;
 
    }
    a{
        background: blue;
        color: #fff;
        padding: 8px 10px;
        text-decoration: none;
        border-radius: 2px;
    }
    </style>
 
    <?php
    header("Content-type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=Data_pcs_global.xls");
    $nama_supp=$_GET['nama_supp'];
    $start_date = date("d F Y",strtotime($_GET['start_date']));
    $end_date = date("d F Y",strtotime($_GET['end_date'])); ?>

    <center>
        <h4>PAYABLE CARD STATEMENT <?php echo $nama_supp; ?><br/> PERIODE <?php echo $start_date; ?> - <?php echo $end_date; ?></h4>
    </center>
 
    <table border="1" >
        <tr>
            <th>No</th>
            <th>Nama Supplier</th>
            <th>Saldo Awal</th>
            <th>Debit</th>
            <th>Credit</th>
            <th>Saldo Akhir</th>
        </tr>
        <?php 
        // koneksi database
        include '../../conn/conn.php';
        $nama_supp=$_GET['nama_supp'];
        $start_date = date("Y-m-d",strtotime($_GET['start_date']));
        $end_date = date("Y-m-d",strtotime($_GET['end_date']));
        // menampilkan data pegawai
        $data = mysqli_query($conn2,"select no_bpb, tgl_bpb, no_po, tgl_po, nama_supp, no_payment, tgl_payment, create_date, curr, SUM(credit_usd) as credit_usd, SUM(debit_usd) as debit_usd, SUM(credit_idr) as credit_idr, SUM(debit_idr) as debit_idr, cek from kartu_hutang where nama_supp != '' and create_date between '$start_date' and '$end_date' and cek >= 1 group by nama_supp  order by create_date asc");

        $no = 1;

        while($row = mysqli_fetch_array($data)){
            $namasupp = $row['nama_supp'];

    $sqls = mysqli_query($conn2,"select a.nama_supp, a.no_kbon, a.status, SUM(a.pph_idr) as pph1, SUM(a.pph_fgn) as pph2, SUM(b.jml_potong) as jml_potong, SUM(b.jml_return) as jml_return  from kontrabon_h a left JOIN potongan b on b.no_kbon = a.no_kbon where a.nama_supp = '$namasupp' and a.confirm_date between '$start_date' and '$end_date' and  a.status = 'Approved' group by a.nama_supp");
    $rows = mysqli_fetch_array($sqls);
    $pph_idr = isset($rows['pph1']) ? $rows['pph1'] : 0;
    $pph_fgn = isset($rows['pph2']) ? $rows['pph2'] : 0;
    $jml_potong = isset($rows['jml_potong']) ? $rows['jml_potong'] : 0;
    $jml_return = isset($rows['jml_return']) ? $rows['jml_return'] : 0;
    $no_kbonh = isset($rows['no_kbon']) ? $rows['no_kbon'] : null;

    $sqlsss = mysqli_query($conn2,"select rate from kartu_hutang group by nama_supp");
    $rowsss = mysqli_fetch_array($sqlsss);
    $rate = isset($rowsss['rate']) ? $rowsss['rate'] : 1;
    $curr = $row['curr'];

    $sqlsww = mysqli_query($conn2,"select a.nama_supp, a.no_kbon, a.status, SUM(a.pph_idr) as pph1, SUM(a.pph_fgn) as pph2, SUM(b.jml_potong) as jml_potong, SUM(b.jml_return) as jml_return  from kontrabon_h a left JOIN potongan b on b.no_kbon = a.no_kbon where a.nama_supp = '$namasupp' and a.confirm_date < '$start_date' and  a.status = 'Approved' group by a.nama_supp");
    $rowsww = mysqli_fetch_array($sqlsww);
    $pph_idr2 = isset($rowsww['pph1']) ? $rowsww['pph1'] : 0;
    $pph_fgn2 = isset($rowsww['pph2']) ? $rowsww['pph2'] : 0;
    $jml_potong2 = isset($rowsww['jml_potong']) ? $rowsww['jml_potong'] : 0;
    $jml_return2 = isset($rowsww['jml_return']) ? $rowsww['jml_return'] : 0;
    $potongan2 = $jml_return2 - $jml_potong2;
    $potongan3 = $potongan2 * $rate;
    $sqlaas = mysqli_query($conn2,"select nama_supp, SUM(credit_usd) as cre_usd, SUM(debit_usd) as deb_usd, SUM(credit_idr) as cre_idr, SUM(debit_idr) as deb_idr from kartu_hutang where nama_supp = '$namasupp' and create_date < '$start_date' and cek >= 1 group by nama_supp");
    $rowaas = mysqli_fetch_array($sqlaas);
    $cre_usd = isset($rowaas['cre_usd']) ? $rowaas['cre_usd'] : 0;
    $deb_usd = isset($rowaas['deb_usd']) ? $rowaas['deb_usd'] : 0;
    $cre_idr = isset($rowaas['cre_idr']) ? $rowaas['cre_idr'] : 0;
    $deb_idr = isset($rowaas['deb_idr']) ? $rowaas['deb_idr'] : 0;
    // $saldo4 = $cre_usd - $deb_usd - $pph_fgn2 - $potongan2;
    // $saldo5 =$cre_idr - $deb_idr - $pph_idr2 - $potongan2;
    if ($curr == 'USD') {
    $saldo5 =$cre_idr - $deb_idr - $pph_idr2 - $potongan3;
    $saldo4 = $cre_usd - $deb_usd - $pph_fgn2 - $potongan2;
    }else{
    $saldo5 =$cre_idr - $deb_idr - $pph_idr2 - $potongan2;
    $saldo4 = $cre_usd - $deb_usd - $pph_fgn2;
}
    if ($curr == 'USD') {
        $saldo = $saldo4;
    }else{
        $saldo = $saldo5;
}

    $potongan = $jml_return - $jml_potong;
    $potongan1 = $potongan * $rate;
    $credit = $row['credit_idr'];
    $debit = $row['debit_idr'];
    $credit1 = $row['credit_usd'];
    $debit2 = $row['debit_usd'];
    
    if($saldo == '0'){
    if ($curr == 'USD') {
    $balance = $credit - $debit - $pph_idr - $potongan1;
    $balance1 = $credit1 - $debit2 - $pph_fgn - $potongan;
    }else{
    $balance = $credit - $debit - $pph_idr - $potongan;
    $balance1 = $credit1 - $debit2 - $pph_fgn;
}
}else{
    if ($curr == 'USD') {
    $balance = $saldo5 + $credit - $debit - $pph_idr - $potongan1;
    $balance1 = $saldo4 + $credit1 - $debit2 - $pph_fgn - $potongan;
    }else{
    $balance = $saldo5 + $credit - $debit - $pph_idr - $potongan;
    $balance1 = $saldo4 + $credit1 - $debit2 - $pph_fgn;
}
}
$curren = $row['curr'];
    if ($curren == "USD") {
       $credit__ = $row['credit_usd'];
       $debit__ = $row['debit_usd'] + $potongan + $pph_fgn;
       $balance__ = $credit__ - $debit__;
    }else{
        $credit__ = $row['credit_idr'];
       $debit__ = $row['debit_idr'] + $potongan + $pph_idr;
       $balance__ = $credit__ - $debit__;
    }


        echo '<tr style="font-size:12px;text-align:center;">
            <td >'.$no++.'</td>
            <td style="text-align:left;" value = "'.$row['nama_supp'].'">'.$row['nama_supp'].'</td>
            <td style="text-align:right;" value = "'.$saldo.'">'.$curren.' '.number_format($saldo,2).'</td>
            <td style="text-align:right;" value = "'.$row['debit_usd'].'">'.$curren.' '.number_format($debit__,2).'</td>         
            <td style="text-align:right;" value = "'.$row['credit_usd'].'">'.$curren.' '.number_format($credit__,2).'</td>
            <td style="text-align:right;" value = "'.$balance1.'">'.$curren.' '.number_format($balance__,2).'</td>
             ';
        ?>
        <?php 
        }
        ?>
    </table>

</body>
</html>




