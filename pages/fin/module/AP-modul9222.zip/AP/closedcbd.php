<?php
include '../../conn/conn.php';
ini_set('date.timezone', 'Asia/Jakarta');

$no_pay = $_POST['no_pay'];
$confirm_date = date("Y-m-d H:i:s");
$update_user = $_POST['update_user'];


if($no_pay == ''){
	echo '';
}else{

$sql = "update list_payment_cbd inner join payment_ftrcbd on payment_ftrcbd.list_payment_id = list_payment_cbd.no_payment set list_payment_cbd.`status` = 'Closed', payment_ftrcbd.keterangan = 'Closed', payment_ftrcbd.closed_date ='$confirm_date', payment_ftrcbd.closed_by = '$update_user' where payment_ftrcbd.payment_ftr_id = '$no_pay'";
$query = mysqli_query($conn2,$sql);

header('Refresh:0; url=formclosing-paycbd.php');
}


if(!$query) {
	die('Error: ' . mysqli_error());	
}

mysqli_close($conn2);

?>