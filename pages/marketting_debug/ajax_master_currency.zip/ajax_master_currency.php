<?php class GetListData {
	public function data($price,$date){
		include "../../include/conn.php";
		$q = "SELECT tanggal, rate_jual,rate_beli,($price * rate_jual) hasiljual,($price / rate_beli) hasilbeli from masterrate WHERE tanggal = '$date'
						";
						
		$stmt = mysql_query($q);

		$outp = '';

		$hasiljual = array();
		$hasilbeli = array();
		while($row=mysql_fetch_array($stmt)){

			array_push($hasiljual,rawurlencode($row['hasiljual']));
			array_push($hasilbeli,rawurlencode($row['hasilbeli']));
		}
		$records[] = array();

		$records['hasiljual'] = $hasiljual;
		$records['hasilbeli'] = $hasilbeli;
			$result = '{ "status":"ok", "message":"", "records":'.json_encode($records).'}';
		return $result;
	}
}


	//print_r($data);
$data = (object)($_POST);
//print_r($data->data['price']);

$date = date('Y-m-d',strtotime($data->data['date']));
//print_r($date);
$GetListData = new GetListData();
$List = $GetListData->data($data->data['price'],$date);
//$data = $List ;
print_r($List);
//echo $data;
?>




