<?PHP
$mod=$_GET['mod'];
$grafik=flookup("grafik","mastercompany","company!='' ");
switch ($mod) 
{	case "1":
		include "dashboard2.php"; break;
	case "2":
		include "m_bom.php";
		break;
	case "3":
		include "quote_inq.php";
		break;
	case "4":
		include "precost.php";
		break;
	case "5": 
		include "actcost.php"; break;
	case "5L":
		include "actcost.php"; break;
	case "5e":
		include "pdfCost.php"; break;
	case "2X":
		include "sample_development.php"; break;
	case "1X":
		include "sample_development.php"; break;
	case "6":
		include "add_item_cs.php";
		break;
	case "7":
		include "sales_ord.php"; break;
	case "7L":
		include "sales_ord.php"; break;
	case "12SO":
		include "so_development.php"; break;
	case "12vSO":
		include "so_development.php"; break;
	case "12A":
		include "sales_ord_dev.php";
	case "7p":
		include "pdfSO.php";
		break;
	case "8":
		include "sales_ord_det.php";
	case "8NEW":
		include "sales_ord_det.php";		
		break;
	case "9":
		include "laporan.php";
		break;
	case "9v":
		include "lap_quote.php";
		break;
	case "10":
		include "laporan.php";
		break;
	case "10v":
		include "lap_pre.php";
		break;
	case "11":
		include "laporan.php";
		break;
	case "11v":
		include "lap_cost.php";
		break;
	case "12":
		include "ws.php"; break;
	case "12L":
		include "ws.php"; break;
	case "12v":
		include "list_so.php";
		break;
	case "13":
		include "ws.php";
		break;
	case "13v":
		include "list_so.php";
		break;
	case "14":
		include "bom_jo.php"; break;
	case "14mu":
		include "bom_jo_mul_upd_dev.php"; break;
	case "14md":
		include "bom_jo.php"; break;
	case "14L":
		include "bom_jo.php"; break;
	case "14d":
		include "bom_jo_item.php";break;
	case "14e":
		include "bom_jo_item_ed.php";break;
	case "15":
		include "pr.php"; break;
	case "15L":
		include "pr.php"; break;
	case "16":
		include "brosur.php";
		break;
	case "17":
		include "laporan.php";
		break;
	case "17v":
		include "lap_so.php";
		break;
	case "18":
		include "laporan.php"; break;
	case "18v":
		include "lap_cost_vs_so.php"; break;
	case "19":
		include "laporan.php"; break;
	case "19v":
		include "lap_hist.php"; break;
	case "20":
		include "un_cost.php"; break;
	case "21":
		include "un_so.php"; break;
	case "22":
		include "bom_jo_dev.php"; break;
	case "22L":
		include "bom_jo_dev.php"; break;
	case "22d":
		include "bom_jo_dev_item.php";break;
	case "22e":
		include "bom_jo_item_ed.php";break;
	case "23":
		include "ws_dev.php"; break;
	case "23L":
		include "ws_dev.php"; break;
	case "23v":
		include "list_so_dev.php"; break;
	case "24":
		include "pr_dev.php"; break;
	case "24L":
		include "pr_dev.php"; break;
	case "x3L":
		include "po_dev.php"; break;
	case "x3":
		include "po_dev.php"; break;
	case "x3e":
		include "po_dev.php"; break;
	case "x3en":
		include "po_notes.php"; break;
	case "x3ea":
		include "po_edit_add.php"; break;
	case "x9":
		include "pr_dev.php"; break;
	case "x9L":
		include "po_dev.php"; break;
	case "x9e":
		include "po_dev.php"; break;		

//	if ($mod=="x3" or $mod=="x3L" or $mod=="x3e")
//	{	include "po_dev.php"; }	
	default:
		echo "<h1>Halaman tidak tersedia</h1>";
		break;
}
?>